=== Plugin Name ===
Contributors: bannerweb
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=Q97G6AMJHPQ3G
Tags: backup, database, msql, sql
Requires at least: 3.0
Tested up to: 3.0
Stable tag: 0.1.2

Simple Wordpress Backup allows you to back up your WordPress Database with just one click!

== Description ==

<p>Simple Wordpress Backup allows you to back up your WordPress Database with just one click.</p>
<p>Creates a full dump of your WordPress MySQL Database.</p>
<p>ATTENTION: alpha Release use at your own risk! Test it before using in your productive environment.</p>

== Frequently Asked Questions ==

Do you have questions or issues with the &quot;Simple Wordpress Backup&quot; plugin?

Please follow us on twitter and ask your question: [@bannerweb](http://twitter.com/bannerweb "@bannerweb")


== Installation ==
1. Unzip and upload the &quot;simple-wordpress-backup&quot; plugin folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create Database Backups with just one click


== Changelog ==

= 0.1.2 =
* [Bug fix](http://wordpress.org/support/topic/plugin-simple-wordpress-backup-wrong-path-in-plugin "Bug fix")

= 0.1.1.1 =
* Minor bug fix

= 0.1.1 =
* Bug fixes

= 0.1 =
* Pre-Alpha release
