# WPHelloWorldPlugin
CathyProductions "Hello World" Wordpress Plugin Demo

Fully functional but minimal Wordpress "Hello World"-Plugin for demo purpose

Created Jan. 2018 

Link: https://www.cathyprod.de/blog/2018/01/27/wordpress-plugin-hello-world-selbst-erstellen/


