# Minimal Click to WhatsApp Plugin

Un plugin sencillo para llevar al cliente a tu número de WhatsApp en tu sitio web sin sobrecargarla con librerías innecesarias.

En esta primera versión las características del plugin son:

✔ Idiomas: Inglés, Castellano.

✔ Página de opciones en los ajustes de WordPress.

✔ Dentro de la página de opciones se puede configurar:

​		✔ Tu número de móvil.

​		✔ Mensaje de texto automático para que el cliente inicie la conversación en tu WhatsApp.

​		✔ Tamaño de icono.

​		✔ Posición del icono en la parte inferior de la pantalla (izquierda o derecha).

