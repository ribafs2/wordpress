# plugin-helloworld-wp
A plugin that displays 'Hello World!' on the top right of your WordPress admin dashboard.
Inspired from the famous 'hello-dolly' plugin that displays the music lyrics.
Trying my hands on creating plugins.

You can customize it to display someother sentence that suits you and use it.
