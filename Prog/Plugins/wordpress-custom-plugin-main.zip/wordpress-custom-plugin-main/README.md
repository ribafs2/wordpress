# wordpress-custom-plugin
WordPress Plugin which is providing the functionality of saving the form data fetcing the data.

# Installation on server side
Upload the files to the "plugin" folder via FTP and activate the plugin.

# Installation locally
Go to wp-content->plugins and the add files.

# Database Setup
Go to the Database Table Directory and import the  "wp_form_plugin_tbl" table into the database.  

# Tech Stacks
Client: HTML5
Server: PHP, WordPress
