# Minimal Share Buttons

WordPress plugin that doesn't spy on users and doesn't slow down you site. This plugin uses simple SVG icons for social network logos and small vanilla JavaScript to allow the user to share the current post or page. Share icons inherit their colours from the theme link colours to match the website design.
