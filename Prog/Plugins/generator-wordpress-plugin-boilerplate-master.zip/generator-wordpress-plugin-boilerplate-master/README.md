# generator-wordpress-plugin-boilerplate
A minimal Yeoman wrapper for devinvinson/WordPress-Plugin-Boilerplate
