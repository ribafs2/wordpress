<?php
/**
 * Dummy index file
 * php version 7.4.2
 * 
 * @category File
 * @package  HelloWorld
 * @author   Sandeep Singh <sandeep.singh.pooni@gmail.com>
 * @license  GPLv2 <https://www.gnu.org/licenses/gpl-2.0.html>
 * @link     n/a
 */

 // do nothing...