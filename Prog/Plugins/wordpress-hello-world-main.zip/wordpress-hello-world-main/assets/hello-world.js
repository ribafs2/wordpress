/**
 * Function to print hello world on browser console
 * @param {string} title 
 */
function HelloWorld(title) {
    console.log('"Hello World!"' + (title ? ' -- ' + title : " -- Latest Post"));
}
