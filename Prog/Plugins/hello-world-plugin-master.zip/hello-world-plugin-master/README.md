# Hello World WordPress Plugin

A simple greeting plugin created for the WordPress Plugin Development Series.
