<?php
/*
 * an empty file or use a header function to redirect to the root url. 
 * @redirect: header('Location: https://yoursite.com');
 *
 */ 
?>