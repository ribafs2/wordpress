#Silence Is Golden
