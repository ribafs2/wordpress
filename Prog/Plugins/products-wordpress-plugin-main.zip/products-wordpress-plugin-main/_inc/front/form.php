<?php
//echo "front\n";