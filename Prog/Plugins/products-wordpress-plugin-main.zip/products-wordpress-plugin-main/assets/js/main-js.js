// jQuery('document').ready(function () {
//     alert('hello front');
// });