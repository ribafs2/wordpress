# minimalist-plugin-list

Extends the WordPress JSON API to list installed plugins with versions

## License

GPLv3
