# default-malaysia-plugin
A WordPress Plugin that will do these when activated.  
  - Delete Hello World post.
  - Delete Akismet & Hello Dolly plugin.
  - Set Timezone to Kuala Lumpur.
  - Set Date Format to d/m/Y.
  - Set Permalink structure to Post name.
  - Install Astra and Hello Elementor theme.
  - Delete all theme except current, Astra & Hello Elementor theme.
