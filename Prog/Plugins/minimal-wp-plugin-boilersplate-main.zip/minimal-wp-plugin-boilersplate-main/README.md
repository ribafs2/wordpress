# minimal-wp-plugin-boilersplate
Here a extra minimal wp plugin boilersplate or skeleton to start your WordPress plugin easily

## Installation
- clone this repo
- rename the folder minimal-wp-plugin-boilersplate with your plugin name
- rename plugin-name.php with your plugin name
- replace the content plugin-name.php with your content
