// import '../wp-block-gen/BlockGenerator'
import BlockGenerator from './wp-block-gen/BlockGenerator';

import config from "./config.json";

new BlockGenerator(config, '../');