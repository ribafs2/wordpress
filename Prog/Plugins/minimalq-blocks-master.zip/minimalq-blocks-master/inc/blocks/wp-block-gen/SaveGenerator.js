/**
 * Save Generator
 */
 
 function SaveGenerator() {
    return <h1>Hello World</h1>;
 }