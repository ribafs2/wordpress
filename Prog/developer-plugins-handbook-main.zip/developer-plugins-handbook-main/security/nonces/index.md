# Nonces

This content has been moved to the [Nonces page](https://developer.wordpress.org/apis/security/nonces/) in the Common APIs Handbook.