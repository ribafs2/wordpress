# Securing (escaping) Output

This content has been moved to the [Escaping Data](https://developer.wordpress.org/apis/security/escaping/) page in the Common APIs Handbook.