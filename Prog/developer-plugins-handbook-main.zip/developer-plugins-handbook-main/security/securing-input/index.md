# Securing (sanitizing) Input

This content has been moved to the [Sanitizing Data](https://developer.wordpress.org/apis/security/sanitizing/) page in the Common APIs Handbook.