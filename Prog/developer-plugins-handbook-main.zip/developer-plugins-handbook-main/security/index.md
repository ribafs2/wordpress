# Plugin Security

This content has been moved to the [Security page](https://developer.wordpress.org/apis/security/) in the Common APIs Handbook.

But there is more content to read...