# WordPress OOP Structure Plugin
This is WordPress OOP structure plugin are build the form crud ( insert, edit and delete ) show the wp list table.
