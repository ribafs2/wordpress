<?php

    
$ser="localhost";
    
$DB="u267385556_MCVxK";
    
$usu="u267385556_uRjXx";
    
$con="0ebqVMzG1x";
    
   $conexion = mysqli_connect($ser,$usu,$con,$DB);
  
// Check connection

//if (!$conexion) {
    //die ("Connection failed: " . mysqli_connect_error());
//}
//echo "Conexion exitosa";
//mysqli_close($conexion);

  
?>