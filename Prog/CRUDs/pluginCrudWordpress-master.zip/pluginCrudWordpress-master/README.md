# pluginCrudWordpress
Es un plugin para agregar un crud a wordpress usando un shortcode
