# plugin-crud-wordpress
Plugin hecho para Wordpress que teine como funcionalidad crear una tabla en la base de datos del proyecto y proporcionar justo en la barra lateral del menú dashboard, una opción donde se accederá al frontend el plugin
