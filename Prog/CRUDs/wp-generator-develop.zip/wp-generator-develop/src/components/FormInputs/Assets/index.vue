<template>
  <div>
    <cssfiles />

    <jsfiles />
  </div>
</template>

<script>
import cssfiles from "./cssfiles";
import jsfiles from "./jsfiles";
export default {
  components: {
    cssfiles,
    jsfiles,
  },
};
</script>

<style lang="scss" scoped></style>
