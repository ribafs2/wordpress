import Prism from "prism-es6";
import "vue-code-highlight/themes/prism-tomorrow.css";
// import "vue-code-highlight/themes/window.css";
import "prism-es6/components/prism-markup-templating";
import "prism-es6/components/prism-php";
