export const eslintignoreCode = () => {
  let code = `**/*.min.js
**/node_modules/**
**/vendor/**
**/build/**
`;

  return code;
};
