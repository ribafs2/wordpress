# wordpress-plugin-crud
wordpress plugin crud

https://diwakaracademy.com/how-to-create-crud-operations-plugin-in-wordpress/
<img src="Capturar.PNG" alt="">
