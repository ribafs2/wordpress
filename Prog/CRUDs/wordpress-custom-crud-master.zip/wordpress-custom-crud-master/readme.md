uncompress the tar xz file of wp-includes
tar -Jxvf wp-includes.tar.xz
